import { Component } from '@angular/core';

@Component({
  selector: 'app-finnhub-footer',
  standalone: true,
  imports: [],
  templateUrl: './finnhub-footer.component.html',
  styleUrl: './finnhub-footer.component.css'
})
export class FinnhubFooterComponent {

}
