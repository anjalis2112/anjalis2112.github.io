export interface FavoriteData {
    id: number;
    ticker: string;
    name: string;
}